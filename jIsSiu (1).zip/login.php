<?php include_once("includes/header.php");
if(isset($_SESSION["name"])){
   echo '<script> 
      window.location.href = "/ecommerce/index.php";
      </script>';
}
?>
<?php 
  if(isset($_POST["login"])){
    include("includes/config.php");
    $email = $_POST["email"];
    $pass = trim($_POST["password"]);
    $query = "SELECT * FROM users WHERE u_email = '$email' AND  u_password = '$pass' ";
    $result = mysqli_query($conn,$query);
    if(mysqli_num_rows($result)>0){
      $res = mysqli_fetch_assoc($result);
      $_SESSION["name"] = $res["u_username"];
      $_SESSION["role"] = $res["u_role"];
      echo '<script> 
      setTimeout(() => {
        window.location.href = "/ecommerce/index.php";
        }, 1000);</script>';
    }else{
      echo "not found";
    }
   
  }

?>
<div class="container p-5 border rounded-4 mt-5 bg-primary-subtle ">
  <h1 class="text-end display-2 text-info ">Login Here</h1>
  <form  method="post">
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" placeholder="Enter Your Email.." name="email" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" class="form-control" placeholder="Enter Your Password.." name="password" required>
    </div>
    <button type="submit" class="btn btn-lg btn-primary " name="login">Login</button>
  </form>
</div>
<script>
</script>
<?php include_once("includes/footer.php") ?>