<?php include_once("includes/header.php") ?>

<div class="container">
    <h1 class="text-center "><img class="col-md-4" src="assets/360_F_506807709_dVXx2UkBR0EHTAuBl1jFBi9mQs43NK8a-removebg-preview.png" alt=""></h1>
    <div class="row d-flex align-items-center mb-5">
        <p class="col-md-12 fs-5 fst-italic ">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laudantium, ducimus. Porro, omnis praesentium. Quidem veritatis voluptas unde, totam atque debitis nihil quaerat in dicta dolor cupiditate voluptatem aperiam facere eum praesentium aspernatur saepe labore repudiandae autem qui quasi quis! Enim quod ab quae veritatis nulla odio officiis obcaecati perferendis sint repellat, fuga adipisci minus tenetur laudantium culpa nam accusantium quas quam optio maxime neque. Doloremque obcaecati distinctio incidunt! Dolores, provident ducimus eligendi iste error officiis nostrum obcaecati maxime rem cupiditate? Fugiat tempora, possimus, amet placeat nulla nostrum reprehenderit eos ex expedita vitae natus nihil sequi cupiditate iure repudiandae mollitia eum.</p>
    </div>
    <hr class="w-100 ">
    <div class="row d-flex align-items-center mb-5">
        <p class="col-md-6 fs-5 fst-italic">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laudantium, ducimus. Porro, omnis praesentium. Quidem veritatis voluptas unde, totam atque debitis nihil quaerat in dicta dolor cupiditate voluptatem aperiam facere eum praesentium aspernatur saepe labore repudiandae autem qui quasi quis! Enim quod ab quae veritatis nulla odio officiis obcaecati perferendis sint repellat, fuga adipisci minus tenetur laudantium culpa nam accusantium quas quam optio maxime neque. Doloremque obcaecati distinctio incidunt! Dolores, provident ducimus eligendi iste error officiis nostrum obcaecati maxime rem cupiditate? Fugiat tempora, possimus, amet placeat nulla nostrum reprehenderit eos ex expedita vitae natus nihil sequi cupiditate iure repudiandae mollitia eum.</p>
        <img class="col-md-6" src="assets/360_F_348488644_pwJuWLaz7xGKUwTiODJmhogLOxzCIAVy-removebg-preview.png" alt="">

    </div>
</div>


<?php include_once("includes/footer.php") ?>