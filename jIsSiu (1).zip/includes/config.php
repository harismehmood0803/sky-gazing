<?php 
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $db = "shop_db";
    $conn = mysqli_connect($hostname,$username,$password,$db);
    if(!$conn){
        die("something went wrong");
    }
?>