<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ecommerce</title>
  <link rel="stylesheet" href="assets/bootstrap.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="bg-dark-subtle position-relative">
<nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="/ecommerce/">E-Commerce</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor02">
      <ul class="navbar-nav ms-auto fw-bold">
        <li class="nav-item">
          <a class="nav-link active" href="/ecommerce/index.php">Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/ecommerce/about.php">About Us</a>
        </li>
        <?php if(!(isset($_SESSION["name"]))){?>
        <li class="nav-item">
          <a class="nav-link" href="/ecommerce/login.php">Login </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/ecommerce/register.php">Register</a>
        </li>
       <?Php }else{?>
        <li class="nav-item">
          <a class="nav-link" href="/ecommerce/logout.php"><?php echo $_SESSION['name']?></a>
        </li>
        <?php } ?>
    </div>
  </div>
</nav>

