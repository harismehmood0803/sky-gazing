<?php include_once("includes/header.php");?>
<div class="container">
    <h1 class="text-center display-1 mt-5"><img src="assets/images-removebg-preview.png" alt=""> </h1>
    <h1>
        <?php 
        if(isset($_SESSION["name"])){
            echo $_SESSION["name"];
            }?>
    </h1>
</div>

<?php include_once("includes/footer.php") ?>