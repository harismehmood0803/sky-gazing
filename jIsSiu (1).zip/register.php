<?php include_once("includes/header.php"); ?>
<?php
if (isset($_POST["submit"])) {
  include("includes/config.php");
  $username = $_POST["username"];
  $email =  $_POST["email"];
  $password =  $_POST["password"];
  // $password = password_hash($pass, PASSWORD_DEFAULT);
  $phone =  $_POST["phone"];
  $selectQuery = "SELECT * FROM users WHERE u_email= '$email'";
  $select = mysqli_query($conn,$selectQuery);
  if(empty($username) || empty($email) || empty($password)){
    $msg = "Fields Are Required";
    $color = "danger";
  }
  elseif(mysqli_num_rows($select)> 0){
    $msg = "Email Already Exist";
    $color = "danger";
  } 
  else{
    $query = "INSERT INTO users(u_username,u_email,u_phone,u_password) VALUE('$username','$email',$phone,'$password')";
    $result = mysqli_query($conn, $query);
    if ($result) {
      $loading = true;
      $loading = false;
      echo '<script> 
      setTimeout(() => {
        window.location.href = "/ecommerce/login.php";
        }, 2000);</script>';
      }
    }
} ?>
<?php if(isset($loading)){ ?>
<div class="loading-screen">
  <div class="spinner-grow text-primary" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-secondary" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-success" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-danger" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-warning" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-info" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-light" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
<div class="spinner-grow text-dark" role="status">
  <span class="visually-hidden">Loading...</span>
</div>
</div>
<?php } ?>
<div class="container p-5 border rounded-4 mt-5 bg-primary-subtle ">
  <h1 class="text-end display-2 text-info">Sign In Here</h1>
  <?php if (!empty($msg)) { ?>
    <div class="alert alert-<?php echo $color; ?> alert-dismissible fade show" role="alert">
      <strong><?php echo $msg; ?></strong>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php } ?>
  <form method="post">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" class="form-control" placeholder="Enter Your Username.." name="username" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" placeholder="Enter Your Email.." name="email" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" class="form-control" placeholder="Enter Your Password.." name="password" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Phone</label>
      <input type="tel" class="form-control" placeholder="Enter Your Phone.." name="phone" required>
    </div>
    <button type="submit" class="btn btn-lg btn-primary " name="submit">Sign In</button>
  </form>
</div>
<script>
</script>
<?php include_once("includes/footer.php") ?>